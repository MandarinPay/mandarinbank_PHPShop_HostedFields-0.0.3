DROP TABLE IF EXISTS `phpshop_modules_mandarinhosted_system`;
delete from `phpshop_payment_systems` where id=10027;
